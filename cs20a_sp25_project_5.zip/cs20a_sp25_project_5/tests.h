#ifndef P5_TESTS_H
#define P5_TESTS_H
void test_insert(int test_size);
void test_search(int test_size);
void test_delete(int test_size);
#endif//P5_TESTS_H